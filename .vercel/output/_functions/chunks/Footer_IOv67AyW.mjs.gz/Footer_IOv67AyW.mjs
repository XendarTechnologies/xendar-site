import { e as createComponent, g as addAttribute, l as renderScript, r as renderTemplate, h as createAstro, n as renderSlot, o as renderHead, u as unescapeHTML, k as renderComponent, m as maybeRenderHead } from './astro/server_oiWRjXm6.mjs';
import 'piccolore';
/* empty css                         */
import 'clsx';

const $$Astro$1 = createAstro();
const $$ClientRouter = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$1, $$props, $$slots);
  Astro2.self = $$ClientRouter;
  const { fallback = "animate" } = Astro2.props;
  return renderTemplate`<meta name="astro-view-transitions-enabled" content="true"><meta name="astro-view-transitions-fallback"${addAttribute(fallback, "content")}>${renderScript($$result, "/mnt/d/dev/xendar-site/node_modules/astro/components/ClientRouter.astro?astro&type=script&index=0&lang.ts")}`;
}, "/mnt/d/dev/xendar-site/node_modules/astro/components/ClientRouter.astro", void 0);

var __freeze = Object.freeze;
var __defProp = Object.defineProperty;
var __template = (cooked, raw) => __freeze(__defProp(cooked, "raw", { value: __freeze(cooked.slice()) }));
var _a;
const $$Astro = createAstro();
const $$Layout = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$Layout;
  const {
    title = "Xendar | Optimizaci\xF3n log\xEDstica para empresas de transporte de carga",
    description = "Xendar optimiza operaciones de transporte de carga con inteligencia de datos: reduce costo por kil\xF3metro, combustible, mantenimiento y kil\xF3metros vac\xEDos.",
    keywords = "software de log\xEDstica, software para empresas de transporte, optimizaci\xF3n log\xEDstica, software para transporte de carga, plataforma log\xEDstica, gesti\xF3n de flotas de camiones, optimizaci\xF3n de transporte de carga, reducci\xF3n de kil\xF3metros vac\xEDos, optimizaci\xF3n de rutas de camiones, software de eficiencia log\xEDstica, costo por kil\xF3metro transporte, control de combustible flota, mantenimiento predictivo camiones",
    canonical = "https://xendar.com.ar",
    ogTitle = "Xendar | Inteligencia log\xEDstica para transporte de carga",
    ogDescription = "Plataforma de optimizaci\xF3n log\xEDstica sin hardware para reducir costos y mejorar eficiencia operativa.",
    ogImage = "https://xendar.com.ar/logo.png",
    twitterTitle = "Xendar | Optimizaci\xF3n log\xEDstica basada en datos",
    twitterDescription = "Menos kil\xF3metros vac\xEDos, mejor costo por kil\xF3metro y control total de flota.",
    bodyClass = ""
  } = Astro2.props;
  const organizationLd = {
    "@context": "https://schema.org",
    "@type": "Organization",
    name: "Xendar",
    url: "https://xendar.com.ar",
    logo: "https://xendar.com.ar/logo.png",
    description: "Plataforma de optimizaci\xF3n log\xEDstica para empresas de transporte de carga.",
    foundingArea: "Argentina",
    industry: "Logistics Technology",
    sameAs: []
  };
  const softwareLd = {
    "@context": "https://schema.org",
    "@type": "SoftwareApplication",
    name: "Xendar",
    applicationCategory: "LogisticsSoftware",
    operatingSystem: "Web",
    description: "Software de optimizaci\xF3n log\xEDstica para flotas y operaciones de transporte de carga.",
    offers: "SaaS",
    areaServed: "Latin America"
  };
  return renderTemplate(_a || (_a = __template(['<html lang="es"> <head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><meta name="robots" content="index, follow"><meta name="description"', '><meta name="keywords"', '><link rel="canonical"', '><meta property="og:title"', '><meta property="og:description"', '><meta property="og:type" content="website"><meta property="og:locale" content="es_AR"><meta property="og:site_name" content="Xendar"><meta property="og:url"', '><meta property="og:image"', '><meta name="twitter:card" content="summary_large_image"><meta name="twitter:title"', '><meta name="twitter:description"', '><meta name="twitter:image"', '><link rel="preload" href="/Xendar-Logo.svg" as="image" type="image/svg+xml"><link rel="preload" href="/fonts/montserrat-400.woff2" as="font" type="font/woff2" crossorigin><link rel="preload" href="/fonts/montserrat-500.woff2" as="font" type="font/woff2" crossorigin><link rel="preload" href="/fonts/montserrat-600.woff2" as="font" type="font/woff2" crossorigin><link rel="preload" href="/fonts/montserrat-700.woff2" as="font" type="font/woff2" crossorigin><link rel="preload" href="/fonts/montserrat-800.woff2" as="font" type="font/woff2" crossorigin><link rel="icon" type="image/svg+xml" href="/favicon.svg"><title>', "</title>", '<script type="application/ld+json">', '<\/script><script type="application/ld+json">', "<\/script>", "</head> <body", "> ", " </body></html>"])), addAttribute(description, "content"), addAttribute(keywords, "content"), addAttribute(canonical, "href"), addAttribute(ogTitle, "content"), addAttribute(ogDescription, "content"), addAttribute(canonical, "content"), addAttribute(ogImage, "content"), addAttribute(twitterTitle, "content"), addAttribute(twitterDescription, "content"), addAttribute(ogImage, "content"), title, renderComponent($$result, "ClientRouter", $$ClientRouter, {}), unescapeHTML(JSON.stringify(organizationLd)), unescapeHTML(JSON.stringify(softwareLd)), renderHead(), addAttribute(`min-h-screen antialiased ${bodyClass}`.trim(), "class"), renderSlot($$result, $$slots["default"]));
}, "/mnt/d/dev/xendar-site/src/layouts/Layout.astro", void 0);

const $$NavBar = createComponent(($$result, $$props, $$slots) => {
  const navLinks = [
    { label: "Seguimiento", href: "/#solutions" },
    { label: "Servicios", href: "/#features" },
    { label: "Sobre Xendar", href: "/about" },
    { label: "Contacto", href: "/contact" }
  ];
  return renderTemplate`${maybeRenderHead()}<header class="fixed top-0 left-0 right-0 z-50 bg-white/80 backdrop-blur-md border-b border-gray-200"> <nav class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8"> <div class="flex items-center justify-between h-16 lg:h-20"> <!-- Logo --> <a href="/" class="flex items-center gap-2 shrink-0 w-[168px] lg:w-[192px]"> <img src="/Xendar-Logo.svg" alt="Xendar" class="h-14 w-auto lg:h-16" width="3615" height="1231" loading="eager" decoding="async"> </a> <!-- Desktop Navigation --> <div class="hidden lg:flex items-center gap-8"> ${navLinks.map((link) => renderTemplate`<a${addAttribute(link.href, "href")} class="text-gray-600 hover:text-navy font-medium transition-colors"> ${link.label} </a>`)} </div> <!-- CTA Buttons --> <div class="hidden lg:flex items-center gap-4"> <a href="/#" class="text-navy font-medium hover:text-blue transition-colors">
Ingresar
</a> <a href="/contact" class="bg-blue text-white px-5 py-2.5 rounded-lg font-medium hover:bg-blue-dark transition-colors">
Solicitar Demo
</a> </div> <!-- Mobile Menu Button --> <button id="mobile-menu-btn" class="lg:hidden p-2 text-navy" aria-label="Abrir menú" aria-controls="mobile-menu" aria-expanded="false"> <svg class="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"> <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"></path> </svg> </button> </div> <!-- Mobile Menu --> <div id="mobile-menu" class="hidden lg:hidden pb-4"> <div class="flex flex-col gap-4"> ${navLinks.map((link) => renderTemplate`<a${addAttribute(link.href, "href")} class="text-gray-600 hover:text-navy font-medium transition-colors py-2"> ${link.label} </a>`)} <div class="flex flex-col gap-3 pt-4 border-t border-gray-200"> <a href="/#" class="text-navy font-medium">
Ingresar
</a> <a href="/contact" class="bg-blue text-white px-5 py-2.5 rounded-lg font-medium text-center">
Solicitar Demo
</a> </div> </div> </div> </nav> </header> ${renderScript($$result, "/mnt/d/dev/xendar-site/src/components/NavBar.astro?astro&type=script&index=0&lang.ts")}`;
}, "/mnt/d/dev/xendar-site/src/components/NavBar.astro", void 0);

const $$Footer = createComponent(($$result, $$props, $$slots) => {
  const footerLinks = {
    solutions: [
      { label: "Optimizaci\xF3n log\xEDstica", href: "/#" },
      { label: "Gesti\xF3n de flotas", href: "/#" },
      { label: "Reducci\xF3n de kil\xF3metros vac\xEDos", href: "/#" },
      { label: "Eficiencia operativa", href: "/#" }
    ],
    company: [
      { label: "Nuestra historia", href: "/about" },
      { label: "Visi\xF3n", href: "/about" },
      { label: "Servicios", href: "/services" },
      { label: "Contacto", href: "/contact" }
    ],
    resources: [
      { label: "Plataforma log\xEDstica", href: "/#solutions" },
      { label: "Software de transporte", href: "/#features" },
      { label: "Solicitar demo", href: "/contact" },
      { label: "Soporte", href: "/contact" }
    ],
    legal: [
      { label: "Privacidad", href: "/#" },
      { label: "T\xE9rminos", href: "/#" },
      { label: "Cookies", href: "/#" }
    ]
  };
  return renderTemplate`${maybeRenderHead()}<footer id="contact" class="bg-navy pt-16 lg:pt-20 pb-8"> <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8"> <h2 class="sr-only">Pie de página</h2> <div class="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-8 lg:gap-12"> <!-- Brand Column --> <div class="col-span-2 lg:col-span-2"> <a href="/" class="flex items-center gap-2"> <img src="/Xendar-Logo-DarkMode.svg" alt="Xendar" class="h-12 w-auto" loading="lazy" decoding="async"> </a> <p class="mt-4 text-gray-400 text-sm leading-relaxed max-w-sm">
Servicio de optimización logística para empresas de transporte de carga.
</p> <!-- Social Links --> <div class="flex gap-4 mt-6"> <a href="https://x.com/xendar" aria-label="Xendar en X" rel="noopener noreferrer" target="_blank" class="w-10 h-10 bg-white/5 rounded-lg flex items-center justify-center text-gray-400 hover:bg-white/10 hover:text-white transition-colors"> <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"> <path d="M24 4.557c-.883.392-1.832.656-2.828.775 1.017-.609 1.798-1.574 2.165-2.724-.951.564-2.005.974-3.127 1.195-.897-.957-2.178-1.555-3.594-1.555-3.179 0-5.515 2.966-4.797 6.045-4.091-.205-7.719-2.165-10.148-5.144-1.29 2.213-.669 5.108 1.523 6.574-.806-.026-1.566-.247-2.229-.616-.054 2.281 1.581 4.415 3.949 4.89-.693.188-1.452.232-2.224.084.626 1.956 2.444 3.379 4.6 3.419-2.07 1.623-4.678 2.348-7.29 2.04 2.179 1.397 4.768 2.212 7.548 2.212 9.142 0 14.307-7.721 13.995-14.646.962-.695 1.797-1.562 2.457-2.549z"></path> </svg> </a> <a href="https://www.linkedin.com/company/xendar" aria-label="Xendar en LinkedIn" rel="noopener noreferrer" target="_blank" class="w-10 h-10 bg-white/5 rounded-lg flex items-center justify-center text-gray-400 hover:bg-white/10 hover:text-white transition-colors"> <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"> <path d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z"></path> </svg> </a> <a href="https://github.com/xendar" aria-label="Xendar en GitHub" rel="noopener noreferrer" target="_blank" class="w-10 h-10 bg-white/5 rounded-lg flex items-center justify-center text-gray-400 hover:bg-white/10 hover:text-white transition-colors"> <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"> <path d="M12 0c-6.626 0-12 5.373-12 12 0 5.302 3.438 9.8 8.207 11.387.599.111.793-.261.793-.577v-2.234c-3.338.726-4.033-1.416-4.033-1.416-.546-1.387-1.333-1.756-1.333-1.756-1.089-.745.083-.729.083-.729 1.205.084 1.839 1.237 1.839 1.237 1.07 1.834 2.807 1.304 3.492.997.107-.775.418-1.305.762-1.604-2.665-.305-5.467-1.334-5.467-5.931 0-1.311.469-2.381 1.236-3.221-.124-.303-.535-1.524.117-3.176 0 0 1.008-.322 3.301 1.23.957-.266 1.983-.399 3.003-.404 1.02.005 2.047.138 3.006.404 2.291-1.552 3.297-1.23 3.297-1.23.653 1.653.242 2.874.118 3.176.77.84 1.235 1.911 1.235 3.221 0 4.609-2.807 5.624-5.479 5.921.43.372.823 1.102.823 2.222v3.293c0 .319.192.694.801.576 4.765-1.589 8.199-6.086 8.199-11.386 0-6.627-5.373-12-12-12z"></path> </svg> </a> </div> </div> <!-- Solutions --> <div> <h3 class="text-white font-semibold mb-4">Soluciones</h3> <ul class="space-y-3"> ${footerLinks.solutions.map((link) => renderTemplate`<li> <a${addAttribute(link.href, "href")} class="text-gray-400 text-sm hover:text-white transition-colors"> ${link.label} </a> </li>`)} </ul> </div> <!-- Company --> <div> <h3 class="text-white font-semibold mb-4">Empresa</h3> <ul class="space-y-3"> ${footerLinks.company.map((link) => renderTemplate`<li> <a${addAttribute(link.href, "href")} class="text-gray-400 text-sm hover:text-white transition-colors"> ${link.label} </a> </li>`)} </ul> </div> <!-- Resources --> <div> <h3 class="text-white font-semibold mb-4">Recursos</h3> <ul class="space-y-3"> ${footerLinks.resources.map((link) => renderTemplate`<li> <a${addAttribute(link.href, "href")} class="text-gray-400 text-sm hover:text-white transition-colors"> ${link.label} </a> </li>`)} </ul> </div> <!-- Legal --> <div> <h3 class="text-white font-semibold mb-4">Legal</h3> <ul class="space-y-3"> ${footerLinks.legal.map((link) => renderTemplate`<li> <a${addAttribute(link.href, "href")} class="text-gray-400 text-sm hover:text-white transition-colors"> ${link.label} </a> </li>`)} </ul> </div> </div> <!-- Bottom Bar --> <div class="mt-12 pt-8 border-t border-white/10"> <div class="flex flex-col md:flex-row items-center justify-between gap-4"> <p class="text-gray-500 text-sm">
&copy; ${(/* @__PURE__ */ new Date()).getFullYear()} Xendar. Todos los derechos reservados.
</p> <div class="flex items-center gap-6 text-sm text-gray-500"> <span class="flex items-center gap-2"> <svg class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"> <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"></path> </svg>
+54 3364 11 3181
</span> <span class="flex items-center gap-2"> <svg class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"> <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"></path> </svg>
contacto@xendar.com.ar
</span> </div> </div> </div> </div> </footer>`;
}, "/mnt/d/dev/xendar-site/src/components/Footer.astro", void 0);

export { $$Layout as $, $$NavBar as a, $$Footer as b };
